"""Pycabnn's version number"""

__version__ = "0.7+dev"
